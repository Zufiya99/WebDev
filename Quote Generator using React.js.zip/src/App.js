import React, { useEffect, useState } from "react";
import "./App.css";

const App = () => {
  const [quote, setQuote] = useState("");
  const [author, setAuthor] = useState("");

  useEffect(() => {
    fetch("https://api.quotable.io/random")
      .then(response => response.json())
      .then(data => {
        setQuote(data.content);
        setAuthor(data.author);
      })
      .catch(error => console.log(error));
  }, []);

  return (
    <>
      <header className="App-header">
        <h1>Quote Generator</h1>
      </header>
      <main>
        <div className="container">
          <div className="text">{quote}</div>
          <div className="author">... {author}</div>
        </div>
        <button className="new-quote" onClick={() => window.location.reload()}>
        Generate
      </button>
      </main>
      <footer>
        <p>&copy; <em>Team Silicon Squad</em></p>
      </footer>
    </>
  )
  };

export default App;
